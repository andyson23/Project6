import java.util.*;
import cards.Deck;
import cards.PlayingCards;
import jsjf.LinkedQueue;

public class WarGame {
	Deck<PlayingCards> deck = new Deck<PlayingCards>(52);
	Player player1 = new Player();
	Player player2 = new Player();
	Player player3 = new Player();
	Player player4 = new Player();
	LinkedQueue<Player> q = new LinkedQueue<Player>();
	Scanner scan = new Scanner(System.in);
	static int numberOfPlayers;
	int round = 1;

	public void numberOfPlayers() {
		System.out.println("How many players? (2 or 4) ");
		numberOfPlayers = scan.nextInt();
	}
	
	public void shuffleDeck() {
		deck.shuffle();
	}
	
	public void dealHands() {
		if(numberOfPlayers == 2) {
			player1.dealtHand(numberOfPlayers);
			player2.dealtHand(numberOfPlayers);
		} else if (numberOfPlayers == 4) {
			player1.dealtHand(numberOfPlayers);
			player2.dealtHand(numberOfPlayers);
			player3.dealtHand(numberOfPlayers);
			player4.dealtHand(numberOfPlayers);
		} else throw new java.lang.Error("Invalid number of players.");
	}
	
	
	public void playGame() {	
		
		//2 players
		if(numberOfPlayers == 2) {
			System.out.println("~~~~~~~~~~~~~~~");
			System.out.println("Round "+round);
			System.out.println("Player 1 cards");
			player1.printCardsInHand();
			System.out.println("vs");
			System.out.println("Player 2 cards");
			player2.printCardsInHand();
			System.out.println("~~~~~~~~~~~~~~~\n");
			
			while(player1.cardsInHand()>0 && player2.cardsInHand()>0) {
				q.enqueue(player1); //first champion
				q.enqueue(player2);
				//if player 1 is the champion - do this
				if(q.first()==player1) {
					if(player1.peek().getValue() >= player2.peek().getValue()) {
						round++;
						player1.playCard();
						System.out.println("Round "+round);
						System.out.println("Player 1");
						player1.printCardsInHand();
						System.out.println("vs");
						System.out.println("Player 2");
						player2.printCardsInHand();
						System.out.println("");
					} else {
						round++;
						player2.playCard();
						System.out.println("Round "+round);
						System.out.println("Player 1");
						player1.printCardsInHand();
						System.out.println("vs");
						System.out.println("Player 2");
						player2.printCardsInHand();
						System.out.println("");
						q.dequeue();
						q.enqueue(player1);
						}
					//if player 2 is the champion - do this
					} else if(q.first()==player2) {
						if(player2.peek().getValue() >= player1.peek().getValue()) {
							round++;
							player2.playCard();
							System.out.println("Round "+round);
							System.out.println("Player 1");
							player1.printCardsInHand();
							System.out.println("vs");
							System.out.println("Player 2");
							player2.printCardsInHand();
							System.out.println("");
						} else {
							round++;
							player1.playCard();
							System.out.println("Round "+round);
							System.out.println("Player 1");
							player1.printCardsInHand();
							System.out.println("vs");
							System.out.println("Player 2");
							player2.printCardsInHand();
							System.out.println("");
							q.dequeue();
							q.enqueue(player2);
						}
					}
			}
			if(player1.cardsInHand()==0)
				System.out.println("Player 1 is the winner!");
			if(player2.cardsInHand()==0)
				System.out.println("Player 2 is the winner!");
		
		//4 players
		if(numberOfPlayers == 4) {
			System.out.println("~~~~~~~~~~~~~~~");
			System.out.println("Player 1 cards");
			player1.printCardsInHand();
			System.out.println("vs");
			System.out.println("Player 2 cards");
			player2.printCardsInHand();
			System.out.println("vs");
			System.out.println("Player 3 cards");
			player3.printCardsInHand();
			System.out.println("vs");
			System.out.println("Player 4 cards");
			player4.printCardsInHand();
			System.out.println("~~~~~~~~~~~~~~~\n");
			
			while(player1.cardsInHand()>0 && player2.cardsInHand()>0 && player3.cardsInHand()>0 && player4.cardsInHand()>0) {
				//queue players (FRONT-1-2-3-4-REAR)
				q.enqueue(player1); //first champion
				q.enqueue(player2);
				q.enqueue(player3);
				q.enqueue(player4);
				//if player 1 is the champion - do this
				while(q.first()==player1) {
					if(player1.peek().getValue() >= player2.peek().getValue()) {
						player1.playCard();
						System.out.println("Player 1 cards");
						player1.printCardsInHand();
						System.out.println("vs");
						System.out.println("Player 2 cards");
						player2.printCardsInHand();
						System.out.println("vs");
						System.out.println("Player 3 cards");
						player3.printCardsInHand();
						System.out.println("vs");
						System.out.println("Player 4 cards");
						player4.printCardsInHand();
						System.out.println("");
					} else {
						player2.playCard();
						System.out.println("Player 1 cards");
						player1.printCardsInHand();
						System.out.println("vs");
						System.out.println("Player 2 cards");
						player2.printCardsInHand();
						System.out.println("vs");
						System.out.println("Player 3 cards");
						player3.printCardsInHand();
						System.out.println("vs");
						System.out.println("Player 4 cards");
						player4.printCardsInHand();
						System.out.println("");
						q.dequeue();
						q.enqueue(player1);
						}
					//if player 2 is the champion - do this
					}

					if(q.first()==player2) {
						if(player2.peek().getValue() >= player1.peek().getValue()) {
							player2.playCard();
							System.out.println("Player 1 cards");
							player1.printCardsInHand();
							System.out.println("vs");
							System.out.println("Player 2 cards");
							player2.printCardsInHand();
							System.out.println("vs");
							System.out.println("Player 3 cards");
							player3.printCardsInHand();
							System.out.println("vs");
							System.out.println("Player 4 cards");
							player4.printCardsInHand();
							System.out.println("");
						} else {
							player1.playCard();
							System.out.println("Player 1 cards");
							player1.printCardsInHand();
							System.out.println("vs");
							System.out.println("Player 2 cards");
							player2.printCardsInHand();
							System.out.println("vs");
							System.out.println("Player 3 cards");
							player3.printCardsInHand();
							System.out.println("vs");
							System.out.println("Player 4 cards");
							player4.printCardsInHand();
							System.out.println("");
							q.dequeue();
							q.enqueue(player2);
						}
					}
				}
			
				if(player1.cardsInHand()==0)
					System.out.println("Player 1 is the winner!");
				if(player2.cardsInHand()==0)
					System.out.println("Player 2 is the winner!");
				if(player3.cardsInHand()==0)
					System.out.println("Player 3 is the winner!");
				if(player4.cardsInHand()==0)
					System.out.println("Player 4 is the winner!");
			
			}
		}
	}
}

