import cards.*;
import jsjf.*;

public class Driver {
	
public static void main(String[] args) {
	
	// Just used to test out classes
	
	Deck d = new Deck(52);
	StackHand hand = new StackHand();
	
	//d.shuffle();
	
	//adds a card to hand
	hand.addCard(d.dealOne());
	hand.addCard(d.dealOne());
	hand.addCard(d.dealOne());
	hand.addCard(d.dealOne());
	hand.addCard(d.dealOne());
	hand.addCard(d.dealOne());
	hand.addCard(d.dealOne());
	hand.addCard(d.dealOne());
	hand.addCard(d.dealOne());
	hand.addCard(d.dealOne());
	hand.addCard(d.dealOne());
	hand.addCard(d.dealOne());
	hand.addCard(d.dealOne());
	hand.addCard(d.dealOne());
	hand.addCard(d.dealOne());
	hand.addCard(d.dealOne());
	hand.addCard(d.dealOne());
	hand.addCard(d.dealOne());
	hand.addCard(d.dealOne());
	hand.addCard(d.dealOne());
	hand.addCard(d.dealOne());
	hand.addCard(d.dealOne());
	hand.addCard(d.dealOne());
	hand.addCard(d.dealOne());
	hand.addCard(d.dealOne());
	hand.addCard(d.dealOne());
	hand.addCard(d.dealOne());
	hand.addCard(d.dealOne());
	hand.addCard(d.dealOne());
	hand.addCard(d.dealOne());
	hand.addCard(d.dealOne());
	hand.addCard(d.dealOne());
	hand.addCard(d.dealOne());
	hand.addCard(d.dealOne());
	hand.addCard(d.dealOne());
	hand.addCard(d.dealOne());
	hand.addCard(d.dealOne());
	hand.addCard(d.dealOne());
	hand.addCard(d.dealOne());
	hand.addCard(d.dealOne());
	hand.addCard(d.dealOne());
	hand.addCard(d.dealOne());
	hand.addCard(d.dealOne());
	hand.addCard(d.dealOne());
	hand.addCard(d.dealOne());
	hand.addCard(d.dealOne());
	hand.addCard(d.dealOne());
	hand.addCard(d.dealOne());
	hand.addCard(d.dealOne());
	hand.addCard(d.dealOne());
	hand.addCard(d.dealOne());
	hand.addCard(d.dealOne());

	//prints hand
	hand.printHand();
	
	//pops a card
	PlayingCards playingcard = hand.play();
	
	//popped card
	System.out.println(playingcard);
	
	System.out.println(hand.size());
	//prints new hand
	hand.printHand();
	}
}
