import java.util.*;

public class Players {

	Queue<Players> player;
	
	public Players(int n) {
		player.
	}
	
	
	
}
