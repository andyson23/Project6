/*
 * Andy Son
 * CSC 205AA
 * Mr. Huber
 * Project 6
 */
package cards;
import java.util.*;

public class Deck<T> implements Iterable<T>{
	
	private static Stack<PlayingCards> cards;
	private Random rand;

	public Deck(int n) {
		super();
		rand = new Random();
		cards = new Stack<PlayingCards>();
		for (int suite = 1; suite <= 4; suite ++)
			for (int rank = 1; rank <= 13; rank ++) {
				if ((suite - 1) * 13 + rank <= n) { 
				  cards.add(new PlayingCards(rank, suite));
				}
			}
	}
	
	public final static void shuffle() {
		Collections.shuffle(cards);
	}
	
	public PlayingCards dealOne() {
		return cards.pop();
	}
	
	public String toString(){
		String ret = "";
		for (PlayingCards card : cards){
			ret += card + "\n";
		}
		return ret;
	}

	public Iterator<T> iterator() {
		Iterator<T> ret = (Iterator<T>) cards.iterator();
		return ret;
	}

}
