/*
 * Andy Son
 * CSC 205AA
 * Mr. Huber
 * Project 5
 */
package cards;
import java.util.Random;

public class PlayingCards {

	private static String suits[] = {"Joker","H", "S", "D", "C"};
	private static String ranks[] = {"Joker","A", "2", "3", "4", "5", "6", "7", "8", "9", 
									"10", "J", "Q", "K"};
	private int rank;
	private int suit;
	private int value;
	
	// Default constructor 
	public PlayingCards ()
	{
		chooseRandomCardValue();
	}
	
	public PlayingCards (int rank, int suit)
	{
		this.rank = 0;
		this.suit = 0;
		if ( (suit > 0) && (suit < suits.length) ) {
			if ( (rank > 0) && (rank < ranks.length) ) {
				this.suit = suit;
				this.rank = rank;
			}
		}
	}
	
	public PlayingCards (String rank, String suit)
	{
		this.rank = find_entry(rank, ranks);
		this.suit = find_entry(suit, suits);
	}	
	
	private static int find_entry(String value, String values[]) 
	{
		int ret = 0;
		for (int ii=0;ii<values.length;ii++)
		{
			if (value.toUpperCase() == values[ii].toUpperCase()) 
				ret = ii;
		}
		return ret;
	}

	private void chooseRandomCardValue()	
	{
		Random randNum = new Random();
		rank = randNum.nextInt(ranks.length-1)+1;
		suit = randNum.nextInt(suits.length-1)+1;
	}
	
	// Getters 
	public int getRank() {
		return rank;
	}
	public int getSuit() {
		return suit;
	}
	public String getRankName() {
		return ranks[rank];
	}
	public String getSuitName() {
		return suits[suit];
	}
	
	public int getValue() {
		if(rank == 0)
			value = 11;
		else if (rank > 9)
			value = 10;
		else
			value = rank+1;
		return value;
	}
	
	// Allow card to be printed nicely
	public String toString ()
	{
		return (ranks[rank]+suits[suit]);
	}
	
}
