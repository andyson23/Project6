/*
 * Andy Son
 * CSC 205AA
 * Mr. Huber
 * Project 6
 */
package cards;

public interface HandOfCards {
	public void addCard(PlayingCards c);
	public void printHand();
}
