import cards.Deck;

public class Round {
	
Deck d = new Deck(52);
Player andy = new Player();
	
	public void Round() {
		
	}
	
}
