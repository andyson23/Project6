/*
 * Andy Son
 * CSC 205AA
 * Mr. Huber
 * Project 6
 */
import java.util.Scanner;

import cards.Deck;
import cards.PlayingCards;

public class MultiWar {

	public static void main(String[] args) {
		WarGame game = new WarGame();
		game.numberOfPlayers();
		game.shuffleDeck();
		game.dealHands();
		game.playGame();
	}

}