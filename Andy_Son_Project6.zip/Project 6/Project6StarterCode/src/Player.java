import cards.Deck;
import cards.PlayingCards;
import jsjf.LinkedQueue;

public class Player {

	 StackHand hand = new StackHand(); 
	 Deck<PlayingCards> deck = new Deck<PlayingCards>(52);
	
	 
	public void dealtHand(int numberOfPlayers) {
		int cardsPerPlayer = (52 / numberOfPlayers);
			for(int ii = 1; ii <= cardsPerPlayer; ii++) {
				hand.addCard(deck.dealOne());
			}
		}
	
	public PlayingCards playCard() {
		return hand.play();
	}
	
	public PlayingCards peek() {
		return hand.peek();
	}
	
	public int cardsInHand() {
		return hand.size();
	}
	
	public void printCardsInHand() {
		if(hand.size()!=0)
			hand.printHand();
		else
			System.out.println("No cards left");
	}
	
}
