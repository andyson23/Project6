/*
 * Andy Son
 * CSC 205AA
 * Mr. Huber
 * Project 5
 */
package cards;

import bag.MyBag;

public class BagHand {

	MyBag<PlayingCards> hands = new MyBag<PlayingCards>();
	
	public void add(PlayingCards c) {
			hands.add(c);
	}

	public void printHand() {
		int i = 1;
		for(PlayingCards hand: hands) {
			System.out.println("Card "+i+": "+hand);
			i++;
		}
	}

	public void getValue() {
		int total = 0;
		  for(PlayingCards hand: hands) {
			  int value = hand.getValue();
			  total += value;
		  }
		  if (total != 21)
			  System.out.println("Value: "+total);
		  else {
			  System.out.println("BlackJack!");

		  }
	}
}
