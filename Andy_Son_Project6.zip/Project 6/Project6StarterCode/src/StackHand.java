import cards.HandOfCards;
import cards.PlayingCards;
import jsjf.LinkedStack;

public class StackHand implements HandOfCards {
	
	LinkedStack<PlayingCards> hand = new LinkedStack<>();
	
	public void addCard(PlayingCards c) {
		if (hand.size()<=51)
			hand.push(c);
		else 
			throw new java.lang.Error("Exceeded standard deck of 52 cards.");
	}

	public void printHand() {
		System.out.print(hand);
	}
	
	public PlayingCards play() {
		return hand.pop();
	}
	
	public PlayingCards peek() {
		return hand.peek();
	}
	
	public int size() {
		return hand.size();
	}

}
