import cards.Deck;

public class Round {
	
Deck d = new Deck(52);
StackHand hand = new StackHand();
	
	public void Round() {
		//
	}
}
