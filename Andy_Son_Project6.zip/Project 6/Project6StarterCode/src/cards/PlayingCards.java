/*
 * Andy Son
 * CSC 205AA
 * Mr. Huber
 * Project 5
 */
package cards;
import java.util.Random;

public class PlayingCards {

	private static String suits[] = {"Joker","H", "S", "D", "C"};
	private static String ranks[] = {"Joker","A", "2", "3", "4", "5", "6", "7", "8", "9", 
									"10", "J", "Q", "K"};
	private int rank;
	private int suit;
	private int value;
	
	// Default constructor 
	public PlayingCards ()
	{
		chooseRandomCardValue();
	}
	
	public PlayingCards (int rank, int suit)
	{
		this.rank = 0;
		this.suit = 0;
		if ( (suit > 0) && (suit < suits.length) ) {
			if ( (rank > 0) && (rank < ranks.length) ) {
				this.suit = suit;
				this.rank = rank;
			}
		}
	}
	
	public PlayingCards (String rank, String suit)
	{
		this.rank = find_entry(rank, ranks);
		this.suit = find_entry(suit, suits);
	}	
	
	private static int find_entry(String value, String values[]) 
	{
		int ret = 0;
		for (int ii=0;ii<values.length;ii++)
		{
			if (value.toUpperCase() == values[ii].toUpperCase()) 
				ret = ii;
		}
		return ret;
	}

	private void chooseRandomCardValue()	
	{
		Random randNum = new Random();
		rank = randNum.nextInt(ranks.length-1)+1;
		suit = randNum.nextInt(suits.length-1)+1;
	}
	
	// Getters 
	public int getRank() {
		return rank;
	}
	public int getSuit() {
		return suit;
	}
	public String getRankName() {
		return ranks[rank];
	}
	public String getSuitName() {
		return suits[suit];
	}
	
	public int getValue() {
		switch (rank) {
		case 1: value = 1;
			    break;
		case 2: value = 2;
				break;		
		case 3: value = 3;
				break;
		case 4: value = 4;
				break;
		case 5: value = 5;
				break;
		case 6: value = 6;
	    		break;
		case 7: value = 7;
	    		break;
		case 8: value = 8;
	    		break;
		case 9: value = 9;
	    		break;
		case 10: value = 10;
	    		break;
		case 11: value = 11;
				break;
		case 12: value = 12;
				break;
		case 13: value = 13;
				break;
		}
		return value;
	}
	
	// Allow card to be printed nicely
	public String toString ()
	{
		return (ranks[rank]+suits[suit]);
	}
	
}
