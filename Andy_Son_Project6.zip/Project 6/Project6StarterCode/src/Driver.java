import java.util.Scanner;

import cards.Deck;
import cards.PlayingCards;

public class Driver {

	public static void main(String[] args) {
		WarGame game = new WarGame();
		game.numberOfPlayers();
		game.shuffleDeck();
		game.dealHands();
		game.playGame();
	}

}