import cards.HandOfCards;
import cards.PlayingCards;
import jsjf.LinkedStack;

public class StackHand implements HandOfCards {
	
	LinkedStack<PlayingCards> hand = new LinkedStack<>();
	
	public void addCard(PlayingCards c) {
		if (hand.size()<=51)
			hand.push(c);
		else 
			throw new java.lang.Error("Exceeded standard deck of 52 cards.");
	}

	public void printHand() {
		if(!hand.isEmpty())
			System.out.println(hand);
		else
			throw new java.lang.Error("No card to print.");
	}
	
	public PlayingCards play() {
		PlayingCards play = hand.pop();
		if(!hand.isEmpty())
			return play;
		else
			throw new java.lang.Error("No card to pop."); //placeholder for win message.
	}
	
	public int size() {
		return hand.size();
	}

}
